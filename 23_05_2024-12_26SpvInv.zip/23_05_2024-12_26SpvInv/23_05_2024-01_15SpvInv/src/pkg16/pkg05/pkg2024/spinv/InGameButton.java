package pkg16.pkg05.pkg2024.spinv;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 *
 * @author Michele
 */
public final class InGameButton extends JButton{
    //Enum bottoni
    public enum TipeOfButton{
        BACK_TO_MENU,
        PLAY_WITH_AI,
        TRY_AGAIN,
        EASY_MODE,
        NORMAL_MODE,
        IMPOSSIBLE_MODE;
    }
    
    //membri
    private TipeOfButton t;
    private Icon iconTryAgain;
    private Icon iconBackToMenu;
    private Icon iconPlayAgainstAI;
    private Icon iconEasyMode;
    private Icon iconNormalMode;
    private Icon iconImpossibleMode;
    
    //Costruttore
    InGameButton(TipeOfButton t) {
        //Init membri
        this.t = t;
        iconTryAgain = new ImageIcon("Resurces/TryAgainIconButton.png");
        iconBackToMenu = new ImageIcon("Resurces/BackToMenuIconButton.png");
        iconPlayAgainstAI = new ImageIcon("Resurces/PlayAgainstAIIconButton.png");
        iconEasyMode = new ImageIcon("Resurces/EasyModeIconButton.png");
        iconNormalMode = new ImageIcon("Resurces/NormalModeIconButton.png");
        iconImpossibleMode = new ImageIcon("Resurces/ImpossibleModeIconButton.png");
        
        //Init Personalizzato dello stato del bottone in base al tipo di bottone
        switch (this.t) {
            case TRY_AGAIN -> {
                //Estetica
                this.setIcon(iconTryAgain);
                this.setBorderPainted(false);
                this.setContentAreaFilled(false);
            }
            case BACK_TO_MENU -> {
                //Estetica
                this.setIcon(iconBackToMenu);
                this.setBorderPainted(false);
                this.setContentAreaFilled(false);
            }
            case PLAY_WITH_AI -> {
                //Estetica
                this.setIcon(iconPlayAgainstAI);
                this.setBorderPainted(false);
                this.setContentAreaFilled(false);
            }
            case EASY_MODE -> {
                //Estetica
                this.setIcon(iconEasyMode);
                this.setBorderPainted(false);
                this.setContentAreaFilled(false);
            }
            case NORMAL_MODE -> {
                //Estetica
                this.setIcon(iconNormalMode);
                this.setBorderPainted(false);
                this.setContentAreaFilled(false);
            }
            case IMPOSSIBLE_MODE -> {
                //Estetica
                this.setIcon(iconImpossibleMode);
                this.setBorderPainted(false);
                this.setContentAreaFilled(false);
            }

        }
        
        //set the button to not be usable at first
        this.setEnabledAndVisible(false);
    }
    
    void setEnabledAndVisible (boolean status){
        this.setVisible(status);
        this.setEnabled(status);
    }
}