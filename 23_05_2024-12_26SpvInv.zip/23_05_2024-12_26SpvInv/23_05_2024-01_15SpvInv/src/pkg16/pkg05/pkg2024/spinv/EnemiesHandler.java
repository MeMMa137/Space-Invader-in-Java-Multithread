package pkg16.pkg05.pkg2024.spinv;

class EnemiesHandler implements Runnable{

    Enemy[] enemies;
    GamePanel gamePanel;
    int currentLevel;
    Thread randomShootingThread;
    
    
    public EnemiesHandler(Enemy[] enemies, GamePanel aThis) {
        this.enemies = enemies;
        this.gamePanel = aThis;
        this.currentLevel = 1;
        this.randomShootingThread = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("-EnemiesHandler's randomShoot thread  " + this + " started");
                while(gamePanel.gameState == GamePanel.GameState.PLAYING)
                    randomShoot(1000);
                System.out.println("-EnemiesHandler's randomShoot thread " + this + " ended");
            }
        });
    }
    
    @Override
    public void run() {
        System.out.println("--EnemiesHandler thread "+ this + " started");
        startEnemyRandomShooting();
        while(gamePanel.gameState == GamePanel.GameState.PLAYING){
            if(checkSwichAllDirection()){
                swichAllDirection();
            }
            
            if(checkVictory()){
                resetHarderGame();
            }else if(checkGameOver()){
                setGameOver();
                break;
            }
            
            allMove();
            
            try{
                Thread.sleep(10);
            }catch(InterruptedException e){
                randomShootingThread.interrupt();
            }
            
            gamePanel.repaint();
        }
        
        System.out.println("--EnemiesHandler thread "+ this + " ended");
    }
    
    private boolean checkSwichAllDirection(){
        for(Enemy e:enemies){
            if(e.swichDirectionCondition() && e.isAlive()){
                return true;
            }
        }
        
        return false;
    }
    
    private boolean checkGameOver(){
        for(Enemy e:enemies){
            if(e.gameOverCondition() && e.isAlive()){
                return true;
            }
        }
        
        return false;
    }
    
    private boolean checkVictory() {
        // Inizializza la variabile ans a true, assumendo che tutti i nemici siano morti
        boolean ans = true;

        for (Enemy e : enemies) {
            // Se almeno un nemico è vivo, imposta ans a false e interrompe il ciclo
            if (e.isAlive()) {
                ans = false;
                break;
            }
        }

        return ans;
    }
    
    private boolean swichAllDirection(){
        for(Enemy e:enemies){
            e.swichDirection();
            e.moveDown(0, 0);
        }
        
        return false;
    }
    
    private void allMove(){
        for(Enemy e:enemies){
            e.moveInDirection();
        }
    }
    
    private void randomShoot(int sleepTime){
        int random = (int) (Math.random() * 22);
        
        if(enemies[random].bullet==null && enemies[random].isAlive()){
            enemies[random].shoot(gamePanel);
            new Thread(enemies[random].bullet).start();
        }
        
        try{
            Thread.sleep(sleepTime);
        }catch(InterruptedException e){}
    }
    
    public void startEnemyRandomShooting(){
        randomShootingThread.start();
    }
    
    private void setGameOver(){
        gamePanel.setGameState(GamePanel.GameState.GAME_OVER);
    }
    
    private void resetHarderGame(){
        currentLevel += 1;
        gamePanel.enemies = gamePanel.initEnemiesArray(enemies);
        
        gamePanel.initHitables();
        
        incrementAllVelocityBy(currentLevel);
        gamePanel.player.addLife();
        
        gamePanel.setEnemyEliminatedCount(0);
    }
    
    public void incrementAllVelocityBy(int amount){
        for(Enemy e:enemies){
            e.setSpeed(e.getSpeed() + amount);
        }
    }
}
