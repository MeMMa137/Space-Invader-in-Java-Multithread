package pkg16.pkg05.pkg2024.spinv;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import javax.swing.ImageIcon;

class BunkerPiece implements BulletListener{

    public enum Piece{
        HL_CORNER(new ImageIcon("assets/Bunker/HL.png")),
        LL_CORNER(new ImageIcon("assets/Bunker/LL.png")),
        HR_CORNER(new ImageIcon("assets/Bunker/HR.png")),
        LR_CORNER(new ImageIcon("assets/Bunker/LR.png")),
        COMPLETE(new ImageIcon("assets/Bunker/Complete.png"));

        ImageIcon image;
        private Piece(ImageIcon image) {
            this.image = image;
        }
    }
    
    private enum DestructionMask{
        _1(new ImageIcon("assets/Bunker/_1.png")),
        _2(new ImageIcon("assets/Bunker/_2.png")),
        _3(new ImageIcon("assets/Bunker/_3.png"));

        ImageIcon image;
        private DestructionMask(ImageIcon image) {
            this.image = image;
        }
    }
    
    private Piece piece;
    private DestructionMask mask;
    private boolean active;
    private int integrity;
    private final GamePanel gamePanel;
    private final Point position;
    
    public BunkerPiece(Point position,GamePanel gamePanel,Piece piece) {
        this.position = position;
        this.piece = piece;
        this.gamePanel = gamePanel;
        this.active = true;
        this.integrity = 4;
    }
    
    @Override
    public void onHitSelf() {
        if (integrity > 0) {
            integrity -= 1;
        }

        if (integrity <= 0) {
            active = false;
            mask = null;
        } else {
            switch (integrity) {
                case 1 -> mask = DestructionMask._1;
                case 2 -> mask = DestructionMask._2;
                case 3 -> mask = DestructionMask._3;
                default -> mask = null;  // Reset the mask if integrity is out of expected range
            }
        }
    }

    @Override
    public void onHitOther() {}

    @Override
    public void onOutOfScreen() {}

    @Override
    public boolean isActive() {
        return active;
    }
    
    @Override
    public Dimension getDimension() {
        return new Dimension(piece.image.getIconWidth(), piece.image.getIconHeight());
    }

    @Override
    public Point getPosition() {
        return position;
    }
    
    public void draw(Graphics g){
        if (active) {
            piece.image.paintIcon(gamePanel, g, position.x, position.y);
            if (mask != null && integrity > 0) {
                mask.image.paintIcon(gamePanel, g, position.x, position.y);
            }
        }
    }
    
}
