package pkg16.pkg05.pkg2024.spinv;

import java.awt.Graphics;
import java.awt.Point;
import javax.swing.ImageIcon;

public abstract class GameEntity implements BulletListener{

    //variables
    protected boolean alive;
    
    protected ImageIcon image;
    
    protected Point position;
    
    protected int speed = 4;
    
    protected Bullet bullet;
    
    public GameEntity(ImageIcon image, Point position){
        this.position = position;
        this.image = image;
    }
    
    public boolean isAlive(){
        return alive;
    }
    
    public Point getPosition(){
        return position;
    }
    
    public int getSpeed(){
        return speed;
    }
    
    public void setPosition(Point position){
        this.position = position;
    }
    
    public void setSpeed(int speed){
        this.speed = speed;
    }
    
    public void shoot(GamePanel gamePanel){
        bullet = new Bullet(this, gamePanel);
    }
    
    public void draw(Graphics g) {
        if (image != null) {
            image.paintIcon(null, g, (int)position.getX(), (int)position.getY());
        }
    }

    public void moveRight(int sleepMillis, int sleepNanos) {
        Point currentPosition = getPosition();
        setPosition(new Point(currentPosition.x + speed, currentPosition.y));
        try{
            Thread.sleep(sleepMillis,sleepNanos);
        }catch(InterruptedException e){}
    }

    public void moveLeft(int sleepMillis, int sleepNanos) {
        Point currentPosition = getPosition();
        setPosition(new Point(currentPosition.x - speed, currentPosition.y));
        try{
            Thread.sleep(sleepMillis,sleepNanos);
        }catch(InterruptedException e){}
    }

    @Override
    public abstract void onHitSelf();

    @Override
    public abstract void onHitOther();

    @Override
    public abstract void onOutOfScreen();
}
