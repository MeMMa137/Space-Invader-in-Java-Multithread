package pkg16.pkg05.pkg2024.spinv;

public class SpInv {

    public static void main(String[] args) {
        new GameFrame();
    }
    
}
