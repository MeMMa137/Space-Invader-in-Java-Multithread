package pkg16.pkg05.pkg2024.spinv;

import java.awt.Dimension;
import java.awt.Point;

interface BulletListener {
    void onHitSelf();
    void onHitOther();
    void onOutOfScreen();

    public boolean isActive();

    public Dimension getDimension();
    public Point getPosition();
}
