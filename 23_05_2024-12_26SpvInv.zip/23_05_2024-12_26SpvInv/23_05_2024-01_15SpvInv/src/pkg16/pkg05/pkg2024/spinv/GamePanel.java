package pkg16.pkg05.pkg2024.spinv;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class GamePanel extends JPanel {

    
    enum GameState {
        IN_MENU,
        GAME_OVER,
        PLAYING;
    }
    
    public enum Difficulty {
        EASY,
        NORMAL,
        IMPOSSIBLE;
    }
    
    //screen variables
    static final int SCREEN_WIDTH = 1070;
    static final int SCREEN_HEIGHT = 669;
    static final private int GRID_XY = 49;

    Dimension dimension;

    //enum
    GameState gameState;
    Difficulty difficulty;
    
    //Buttons
    InGameButton buttonTryAgain;
    InGameButton buttonBackToMenu;
    InGameButton buttonPlayWithAI;
    InGameButton buttonEasyMode;
    InGameButton buttonNormalMode;
    InGameButton buttonImpossibleMode;
    
    //images - backgrounds
    ImageIcon inMenuBackground;
    ImageIcon playingBackground;
    ImageIcon gameOverBackground;
    
    //fonts
    private Font customFont;
    
    //Bunkers
    Bunker[] bunkers;
    
    //Entities
    Player player;
    Thread playerThread;
    Enemy[] enemies;
    
    EnemiesHandler eH;
    Thread eHThread;
    private int enemyEliminatedCount = 0; // Variabile per contare i nemici eliminati e di conseguenza aumentare la velocita
    
    BulletListener[] hitables;
    
    public GamePanel() {
        //screen variables
        dimension = new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT);
        this.setPreferredSize(dimension);
        
        //enum
        setGameState(GameState.IN_MENU);
        setDifficulty(Difficulty.NORMAL);
        
        //buttons
        buttonTryAgain = new InGameButton(InGameButton.TipeOfButton.TRY_AGAIN);
        buttonBackToMenu = new InGameButton(InGameButton.TipeOfButton.BACK_TO_MENU);
        buttonPlayWithAI = new InGameButton(InGameButton.TipeOfButton.PLAY_WITH_AI);
        buttonEasyMode = new InGameButton(InGameButton.TipeOfButton.EASY_MODE);
        buttonNormalMode = new InGameButton(InGameButton.TipeOfButton.NORMAL_MODE);
        buttonImpossibleMode = new InGameButton(InGameButton.TipeOfButton.IMPOSSIBLE_MODE);
        //addButtons
        this.add(buttonTryAgain);
        this.add(buttonBackToMenu);
        this.add(buttonPlayWithAI);
        this.add(buttonEasyMode);
        this.add(buttonNormalMode);
        this.add(buttonImpossibleMode);
        
        //images
        inMenuBackground = new ImageIcon("assets/inMenuBackground.png");
        playingBackground = new ImageIcon("assets/playingBackground.png");
        gameOverBackground = new ImageIcon("assets/gameOverBackground.png");
        
        //fonts
        try {
            // Carica il font dal file
            customFont = Font.createFont(Font.TRUETYPE_FONT, new File("fonts/retroGaming.ttf")).deriveFont(24f); // 24f è la dimensione del font

            // Registra il font nel GraphicsEnvironment
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(customFont);
        } catch (IOException | FontFormatException e) {
            System.err.println("[FAILED] Caricamento Font");
        }
    }
    
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        draw(g);
    }
    
    private void draw(Graphics g) {
        switch (gameState) {
            case IN_MENU -> {
                drawInMenu(g);
            }
            case PLAYING -> {
                drawPlaying(g);
            }
            case GAME_OVER -> {
                drawGameOver(g);
            }
            default -> throw new AssertionError();
        }
    }
    
    private void drawInMenu(Graphics g) {
        inMenuBackground.paintIcon(this, g, 0, 0);
        useEasyModeButton();
        useNormalModeButton();
        useImpossibleModeButton();
        usePlayWithAIButton();
        //rettangolo di selezione della difficolta
        drawSelectedDifficulty(g);
    }
    
    private void drawSelectedDifficulty(Graphics g) {
        g.setColor(new Color(185, 183, 0));
        
        switch (difficulty) {
            case EASY -> {
                g.fillRect(GRID_XY+50, GRID_XY+30+10+15+10+15+15, 2, 15);
            }
            case NORMAL -> {
                g.fillRect(GRID_XY+50, GRID_XY+30+10+15+10+15+10+15+15, 2, 15);
            }
            case IMPOSSIBLE -> {
                g.fillRect(GRID_XY+50, GRID_XY+30+10+15+10+15+10+15+10+15+15, 2, 15);
            }
        }
    }
    
    private void drawPlaying(Graphics g) {
        playingBackground.paintIcon(this, g, 0, 0);
        
        
        // Imposta il font personalizzato
        g.setFont(customFont);

        // Imposta il colore del testo
        g.setColor(Color.WHITE);

        if(player != null){
            // Disegna la stringa
            g.drawString("<Your Score> :"+player.getScore(), 20, 30);
            g.drawString("<Best Score> :"+ player.getBestScore(), SCREEN_WIDTH-(g.getFontMetrics().stringWidth("<Best Score> :"+ player.getBestScore()))-20, 30);
        }
        
        player.draw(g);
        drawEnemys(g);
        if(difficulty == Difficulty.EASY || difficulty == Difficulty.NORMAL){
            for(Bunker b:bunkers)
                b.draw(g);
        }
    }
    
    private void drawGameOver(Graphics g) {
        gameOverBackground.paintIcon(this, g, 0, 0);
        
        buttonsGameOver();
    }
    
    public void setGameState(GameState state){
        switch (state) {
            case PLAYING -> {
                this.gameState=GameState.PLAYING; 
                stopCurrentThreads();
                
                //Entities
                player = new Player(new Point(51,594),this);
                enemies = new Enemy[55];
                
                initDifficultyEnviroment();
                
                setEnemyEliminatedCount(0);
                
                initHitables();
                                
                startEnemiesHandler();
                startPlayer();
            }
            case GAME_OVER -> {
                stopCurrentThreads();
                allGameObjToNull();
                this.gameState=GameState.GAME_OVER;
            }
            case IN_MENU -> {
                stopCurrentThreads();
                this.gameState=GameState.IN_MENU;
            }
            default -> throw new AssertionError();
        }
    }
    
    public void initDifficultyEnviroment(){
        switch (difficulty) {
            case EASY -> {
                player.addLife();
                player.addLife();
                eH = new EnemiesHandler(initEnemiesArray(this.enemies), this);

                bunkers = new Bunker[4];
                for (int i = 0; i < bunkers.length; i++) {
                    bunkers[i] = new Bunker(new Point(97 + (193 * i)+(72*i), 500), this);
                }

            }
            case NORMAL -> {
                eH = new EnemiesHandler(initEnemiesArray(this.enemies), this);

                bunkers = new Bunker[4];
                for (int i = 0; i < bunkers.length; i++) {
                    bunkers[i] = new Bunker(new Point(97 + (193 * i)+(72*i), 500), this);
                }
            }
            case IMPOSSIBLE -> {
                eH = new EnemiesHandler(initEnemiesArray(this.enemies), this);
            }
            default -> throw new AssertionError();
        }
    }
    
    private void allGameObjToNull() {
        player = null;
        enemies = null;
        eH = null;
        bunkers = null;
    }
    
    public void setDifficulty(Difficulty difficulty){
        switch (difficulty) {
            case EASY -> {
                this.difficulty = difficulty;
                
            }
            case NORMAL -> {
                this.difficulty = difficulty;
                
            }
            case IMPOSSIBLE -> {
                this.difficulty = difficulty;
                
            }
            default -> throw new AssertionError();
        }
    }
    
    public int getEnemyEliminatedCount() {
        return enemyEliminatedCount;
    }
    
    public void setEnemyEliminatedCount(int count) {
        this.enemyEliminatedCount = count;
    }

    public void incrementEnemyEliminatedCount() {
        enemyEliminatedCount++;
    }
    
    public void initHitables() {
        int totalBunkerPieces = 0;
        if(difficulty == Difficulty.EASY || difficulty == Difficulty.NORMAL){
            // Calculate the correct length for the hitables array
            for (Bunker bunker : bunkers) {
                totalBunkerPieces += bunker.listenersPiecesToArray().length;
            }
        }
        hitables = new BulletListener[enemies.length + 1 + totalBunkerPieces];  // 55 enemies + 1 player + bunker pieces
        hitables[0] = player;
        System.arraycopy(enemies, 0, hitables, 1, enemies.length);

        int startIdx = enemies.length + 1;  // Start index after player and enemies
        if(difficulty == Difficulty.EASY || difficulty == Difficulty.NORMAL){
            for (Bunker bunker : bunkers) {
                BulletListener[] pieces = bunker.listenersPiecesToArray();
                System.arraycopy(pieces, 0, hitables, startIdx, pieces.length);
                startIdx += pieces.length;
            }
        }
    }
    
    public Enemy[] initEnemiesArray(Enemy[] enemies) {
        final int ENEMY_OFFSET_W = 70;
        final int ENEMY_OFFSET_H = 50;
        final int BONUS_NAV_OFFSET_H = 65;
        final int ENEMY_INITIAL_X = 11;
        for(int i=0;i<enemies.length;i++){
            if(i<11){
                enemies[i] = new Enemy(new Point(/*X:*/i*ENEMY_OFFSET_W+ENEMY_INITIAL_X,
                                                /*Y:*/0+BONUS_NAV_OFFSET_H),
                                                Enemy.EnemyType.TYPE_1,
                                                /*a pointer to this gamePanel*/this);
            }else if(i<22){
                enemies[i] = new Enemy(new Point(/*X:*/(i%11)*ENEMY_OFFSET_W+ENEMY_INITIAL_X,
                                                /*Y:*/ENEMY_OFFSET_H+BONUS_NAV_OFFSET_H),
                                                Enemy.EnemyType.TYPE_2,
                                                /*a pointer to this gamePanel*/this);
            }else{
                enemies[i] = new Enemy(new Point(/*X:*/(i%11)*ENEMY_OFFSET_W+ENEMY_INITIAL_X,
                                                /*Y:*/(i/11)*ENEMY_OFFSET_H+BONUS_NAV_OFFSET_H),
                                                Enemy.EnemyType.TYPE_3,
                                                /*a pointer to this gamePanel*/this);
            }
        }
        return enemies;
    }
    
    private void drawEnemys(Graphics g) {
        for(Enemy i: enemies){
            if(i.isAlive()){
                i.draw(g);
            }
        }
    }
    
    private void startPlayer() {
        playerThread = new Thread(player);
        playerThread.start();
    }
    
    private void startEnemiesHandler() {
        eHThread = new Thread(eH);
        eHThread.start();
    }
    
    private void stopCurrentThreads() {
        try{
            if (eHThread != null) {
                eHThread.interrupt();
            }
            if (playerThread != null && playerThread.isAlive()) {
                playerThread.interrupt();
            }
        }catch(Exception e){}
    }
    
    private void buttonsGameOver () {
    //bottoni:
        //try again
        useTryAgainButton();
        //back to menu
        useBackToMenuButton();
    }
    
    private void useTryAgainButton(){
        buttonTryAgain.setEnabledAndVisible(true);
        buttonTryAgain.setBounds
        (
            //x
            (SCREEN_WIDTH - buttonTryAgain.getWidth())/2,
            //y
            (SCREEN_HEIGHT + 50)/2,
            //Width and Height
            buttonTryAgain.getWidth(),
            buttonTryAgain.getHeight()
        );
        
        //Funzionalita
        buttonTryAgain.addActionListener((ActionEvent e) -> {
            if(this.gameState != GameState.PLAYING) 
                setGameState(GameState.PLAYING);
            
            repaint();
            
            buttonTryAgain.setEnabledAndVisible(false);
            buttonBackToMenu.setEnabledAndVisible(false);
        });
    }

    private void useBackToMenuButton(){
        buttonBackToMenu.setEnabledAndVisible(true);
        buttonBackToMenu.setBounds
        (
            //x
            15,
            //y
            15,
            //Width and Height
            buttonBackToMenu.getWidth(),
            buttonBackToMenu.getHeight()
        );
        //Funzionalita
        buttonBackToMenu.addActionListener((ActionEvent e) -> {
            setGameState(GameState.IN_MENU);
            
            repaint();
            
            buttonTryAgain.setEnabledAndVisible(false);
            buttonBackToMenu.setEnabledAndVisible(false);
        });
    }
    
    private void useEasyModeButton(){
        buttonEasyMode.setEnabledAndVisible(true);
        buttonEasyMode.setBounds
        (
            //x
            GRID_XY+50,
            //y
            GRID_XY+30+10+15+10+15+10,
            //Width and Height
            buttonEasyMode.getWidth(),
            buttonEasyMode.getHeight()
        );
        //Funzionalita
        buttonEasyMode.addActionListener((ActionEvent e) -> {
            setDifficulty(Difficulty.EASY);
            repaint();
        });
    }
    
    private void useNormalModeButton(){
        buttonNormalMode.setEnabledAndVisible(true);
        buttonNormalMode.setBounds
        (
            //x
            GRID_XY+50,
            //y
            GRID_XY+30+10+15+10+15+10+15+10,
            //Width and Height
            buttonNormalMode.getWidth(),
            buttonNormalMode.getHeight()
        );
        //Funzionalita
        buttonNormalMode.addActionListener((ActionEvent e) -> {
            setDifficulty(Difficulty.NORMAL);
            repaint();
        });
    }
    
    private void useImpossibleModeButton(){
        buttonImpossibleMode.setEnabledAndVisible(true);
        buttonImpossibleMode.setBounds
        (
            //x
            GRID_XY+50,
            //y
            GRID_XY+30+10+15+10+15+10+15+10+15+10,
            //Width and Height
            buttonImpossibleMode.getWidth(),
            buttonImpossibleMode.getHeight()
        );
        //Funzionalita
        buttonImpossibleMode.addActionListener((ActionEvent e) -> {
            setDifficulty(Difficulty.IMPOSSIBLE);
            repaint();
        });
    }
    
    private void usePlayWithAIButton(){
        buttonPlayWithAI.setEnabledAndVisible(true);
        buttonPlayWithAI.setBounds
        (
            //x
            GRID_XY+20,
            //y
            GRID_XY+30+10+15+10,
            //Width and Height
            buttonPlayWithAI.getWidth(),
            buttonPlayWithAI.getHeight()
        );
        //Funzionalita
        buttonPlayWithAI.addActionListener((ActionEvent e) -> {
            if(this.gameState != GameState.PLAYING) 
                setGameState(GameState.PLAYING);
            
            repaint();
            
            buttonPlayWithAI.setEnabledAndVisible(false);
            buttonEasyMode.setEnabledAndVisible(false);
            buttonNormalMode.setEnabledAndVisible(false);
            buttonImpossibleMode.setEnabledAndVisible(false);
        });
    }
}
