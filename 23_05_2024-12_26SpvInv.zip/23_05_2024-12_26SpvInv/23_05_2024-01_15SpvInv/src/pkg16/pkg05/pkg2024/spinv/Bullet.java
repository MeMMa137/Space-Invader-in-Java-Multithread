package pkg16.pkg05.pkg2024.spinv;

import java.awt.Graphics;
import java.awt.Point;
import javax.swing.ImageIcon;

class Bullet implements Runnable{

    enum BulletType{
        TYPE_1(new ImageIcon("assets/bullet.png")),
        TYPE_2(new ImageIcon("assets/bullet2.png"));

        ImageIcon image;
        private BulletType(ImageIcon image) {
            this.image=image;
        }
    }
    
    protected ImageIcon image;
    protected Point position;
    protected GamePanel gamePanel;
    protected GameEntity father;
    
    Bullet(GameEntity anEntity, GamePanel gamePanel) {
        this(anEntity,gamePanel,BulletType.TYPE_1);
    }
    
    Bullet(GameEntity anEntity, GamePanel gamePanel, BulletType bulletTipe) {
        this.father = anEntity;
        this.position = new Point(anEntity.position.x+anEntity.image.getIconWidth()/2, anEntity.position.y);
        this.gamePanel = gamePanel;
        this.image = bulletTipe.image;
    }
    
    public void draw(Graphics g){
        image.paintIcon(gamePanel, g, position.x, position.y);
    }
    
    private void updatePosition(){
        if(father instanceof Player){
            moveUp(16,0);
        }
        if(father instanceof Enemy){
            moveDown(16, 0);
        }
    }
    
    public void moveDown(int sleepMillis, int sleepNanos) {
        Point currentPosition = position;
        position = new Point(currentPosition.x, currentPosition.y + 10);
        try{
            Thread.sleep(sleepMillis,sleepNanos);
        }catch(InterruptedException e){}
    }
    
    public void moveUp(int sleepMillis, int sleepNanos) {
        Point currentPosition = position;
        position = new Point(currentPosition.x, currentPosition.y - 10);
        try{
            Thread.sleep(sleepMillis,sleepNanos);
        }catch(InterruptedException e){}
    }
    
    private synchronized BulletListener checkHit() {
        for (BulletListener hitable : gamePanel.hitables) {
            if (hitable.isActive() && inHitBoxCondition(hitable)) {
                if (father instanceof Enemy && hitable instanceof Enemy){
                    return null;
                }else{
                    return hitable;
                }
            }
        }
        return null;
    }

    
    private boolean inHitBoxCondition(BulletListener e) {
        return this.position.x>e.getPosition().x && this.position.x<(e.getDimension().getWidth()+e.getPosition().x) &&
                this.position.y>e.getPosition().y && this.position.y<(e.getDimension().getHeight()+e.getPosition().y);
    }
    
    private boolean checkOutOfScreen() {
        return position.y>640 - image.getIconHeight() || position.y<0 + image.getIconHeight();
    }

    @Override
    public void run() {
        BulletListener e = null;

        while (!checkOutOfScreen()) {
            e = checkHit();
            if (e != null) {
                break;
            }
            updatePosition();
        }

        if (checkOutOfScreen()) {
            father.onOutOfScreen();
        } else {
            e.onHitSelf();
            father.onHitOther();
        }
    }
}
