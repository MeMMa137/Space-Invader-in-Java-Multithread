package pkg16.pkg05.pkg2024.spinv;

import java.awt.Graphics;
import java.awt.Point;

class Bunker {
    BunkerPiece[] pieces;
    Point position;
    GamePanel gamePanel;

    public Bunker(Point position, GamePanel gamePanel) {
        this.position = position;
        this.gamePanel = gamePanel;
        pieces = new BunkerPiece[10];
        initPieces();
    }

    private void initPieces() {
        int index = 0;
        for (int i = 0; i < 12; i++) {
            if (i == 9 || i == 10) continue; // Salta gli indici 5 e 6 per evitare i pezzi centrali non necessari

            switch (i) {
                case 0 -> pieces[index] = new BunkerPiece(position, gamePanel, BunkerPiece.Piece.HL_CORNER);
                case 3 -> pieces[index] = new BunkerPiece(new Point(position.x + BunkerPiece.Piece.HR_CORNER.image.getIconWidth() * 3,
                        position.y), gamePanel, BunkerPiece.Piece.HR_CORNER);
                case 8 -> pieces[index] = new BunkerPiece(new Point(position.x,
                        position.y + BunkerPiece.Piece.LL_CORNER.image.getIconHeight() * 2), gamePanel, BunkerPiece.Piece.LL_CORNER);
                case 11 -> pieces[index] = new BunkerPiece(new Point(position.x + BunkerPiece.Piece.LR_CORNER.image.getIconWidth() * 3,
                        position.y + BunkerPiece.Piece.LR_CORNER.image.getIconHeight() * 2), gamePanel, BunkerPiece.Piece.LR_CORNER);
                default -> {
                    int x = position.x + BunkerPiece.Piece.COMPLETE.image.getIconWidth() * (i % 4);
                    int y = position.y + BunkerPiece.Piece.COMPLETE.image.getIconHeight() * (i / 4);
                    pieces[index] = new BunkerPiece(new Point(x, y), gamePanel, BunkerPiece.Piece.COMPLETE);
                }
            }
            index++;
        }
    }
    
    public void draw(Graphics g){
        for(BunkerPiece p:pieces){
            p.draw(g);;
        }
    }
    
    public BulletListener[] listenersPiecesToArray(){
        return pieces;
    }
}
