package pkg16.pkg05.pkg2024.spinv;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.ImageIcon;

class Player extends GameEntity implements Runnable,BulletListener{

    //variables
    private ImageIcon lifeImage;
    
    //movement
    private boolean leftPressed = false;
    private boolean rightPressed = false;
    private boolean spacePressed = false;
    
    //pointer to gamepanel
    private static GamePanel gamePanel;
    
    //players values
    private int bestScore;
    private int score;
    private int lifes;
    
    public Player(Point position, GamePanel aThis) {
        super(new ImageIcon("assets/player.png"), position);
        score = 0;
        lifes = 3;
        super.alive = true;
        super.speed = 7;
        super.bullet=null;
        this.lifeImage = new ImageIcon("assets/playerLife.png");
        this.gamePanel = aThis;
        this.gamePanel.setFocusable(true);
        this.gamePanel.addKeyListener(new MyKeyAdapter());
        this.bestScore = loadBestScore();
    }
    
   
    @Override
    public void run(){
        System.out.println("\n\n----------------------------------------------------");
        System.out.println("---Player thread " + this + " started");
        while(gamePanel.gameState ==GamePanel.GameState.PLAYING){
            updateState();
        }
        if(score > bestScore)
            saveBestScore(score);
        System.out.println("---Player thread " + this + " ended");
    }
    
    @Override
    public void draw(Graphics g) {
        super.draw(g);
        drawLifes(g);
        if(bullet!=null)
            bullet.draw(g);
    }
    
    @Override
    public void onHitSelf(){
        lifes -=1;
        if(lifes < 0){
            alive = false;
            gamePanel.setGameState(GamePanel.GameState.GAME_OVER);
        }
    }
    
    @Override
    public void onHitOther(){
        bullet = null;
    }
    @Override
    public void onOutOfScreen(){
        bullet = null;
    }

    @Override
    public boolean isActive() {
        return isAlive();
    }
    
    @Override
    public Dimension getDimension() {
        return new Dimension(image.getIconWidth(), image.getIconHeight());
    }

    @Override
    public Point getPosition() {
        return position;
    }
    
    public void addLife(){
        lifes += 1;
    }
    
    public void addScore(int amount){
        score += amount;
    }
    
    public int getScore(){
        return score;
    }
    
    private void drawLifes (Graphics g){
        for(int i=0;i<lifes;i++){
            lifeImage.paintIcon(gamePanel, g, 40+(i*40), 640);
        }
    }
    
    private void updateState() {
        if (leftPressed && position.x > 50){
            moveLeft(16,0);
        }else if (rightPressed && position.x < 1030-61) {
            moveRight(16,0);
        }
        if (spacePressed && bullet==null) {
            shoot(gamePanel);
            new Thread(bullet).start();
        }
        gamePanel.repaint();
    }

    public int getBestScore() {
        return bestScore;
    }
    
    public static void saveBestScore(int bestScore) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("bestScore.txt"))) {
            writer.write(String.valueOf(bestScore));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static int loadBestScore() {
        int bestScore = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader("bestScore.txt"))) {
            String line = reader.readLine();
            if (line != null && !line.isEmpty()) {
                bestScore = Integer.parseInt(line.trim());
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
        return bestScore;
    }
    
    private class MyKeyAdapter implements KeyListener {

        @Override
        public void keyPressed(KeyEvent e){
            switch(e.getKeyCode()){
                case KeyEvent.VK_LEFT -> leftPressed = true;
                case KeyEvent.VK_RIGHT -> rightPressed = true;
                case KeyEvent.VK_SPACE -> spacePressed = true;
            }
        }

        @Override
        public void keyReleased(KeyEvent e){
            switch(e.getKeyCode()){
                case KeyEvent.VK_LEFT -> leftPressed = false;
                case KeyEvent.VK_RIGHT -> rightPressed = false;
                case KeyEvent.VK_SPACE -> spacePressed = false;
            }
        }

        @Override
        public void keyTyped(KeyEvent e) {
           
        }
    }
}
