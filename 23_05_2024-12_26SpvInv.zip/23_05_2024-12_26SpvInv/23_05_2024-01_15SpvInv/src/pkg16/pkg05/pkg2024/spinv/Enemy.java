package pkg16.pkg05.pkg2024.spinv;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import javax.swing.ImageIcon;

class Enemy extends GameEntity implements BulletListener{

    public enum EnemyType{
        TYPE_1,
        TYPE_2,
        TYPE_3;
    }
    
    public enum Direction{
        L,
        R;
    }
    
    //varibles
    EnemyType enemyType;
    Direction direction;
    
    GamePanel gamePanel;
    
    public Enemy(GamePanel aThis){
        this(new Point(0,0),EnemyType.TYPE_1, aThis);
    }
    
    public Enemy(Point position,EnemyType enemyType, GamePanel aThis){
        super(new ImageIcon("assets/enemy.png"), position);
        
        switch (enemyType) {
            case TYPE_1 -> {
                super.image = new ImageIcon("assets/enemy1.png");
            }
            case TYPE_2 -> {
                super.image = new ImageIcon("assets/enemy2.png");
            }
            case TYPE_3 -> {
                super.image = new ImageIcon("assets/enemy3.png");
            }
            default -> throw new AssertionError();
        }
        
        this.direction = Direction.R;
        this.enemyType = enemyType;
        this.alive = true;
        this.speed = 1;
        this.gamePanel = aThis;
    }
    
    @Override
    public void draw(Graphics g) {
        super.draw(g);
        if(bullet!=null)
            bullet.draw(g);
    }
    
    @Override
    public void onHitSelf(){
        
        //System.err.println("enemy self hit");
        alive = false;
        
        switch(enemyType){
            case TYPE_1 -> {
                gamePanel.player.addScore(30);
            }
            case TYPE_2 -> {
                gamePanel.player.addScore(20);
            }
            case TYPE_3 -> {
                gamePanel.player.addScore(10);
            }
        }
        
        gamePanel.incrementEnemyEliminatedCount();
        
        if(gamePanel.getEnemyEliminatedCount() == 50){
            gamePanel.eH.incrementAllVelocityBy(1);
        }
        
        if(gamePanel.getEnemyEliminatedCount() == 54){
            gamePanel.eH.incrementAllVelocityBy(1);
        }
    }
    
    @Override
    public void onHitOther(){
        bullet = null;
    }
    @Override
    public void onOutOfScreen(){
        bullet = null;
    }
    @Override
    public boolean isActive() {
        return isAlive();
    }
    
    @Override
    public Dimension getDimension() {
        return new Dimension(image.getIconWidth(), image.getIconHeight());
    }

    @Override
    public Point getPosition() {
        return position;
    }
    
    @Override
    public void shoot(GamePanel gamePanel){
        switch (enemyType) {
            case TYPE_1->{
                bullet = new Bullet(this, gamePanel,Bullet.BulletType.TYPE_1);
            }
            case TYPE_2->{
                bullet = new Bullet(this, gamePanel,Bullet.BulletType.TYPE_2);
            }
            case TYPE_3->{
                
            }
            default -> throw new AssertionError();
        }
    }
    
    public void moveInDirection(){
        switch (direction) {
            case L -> {
                moveLeft(0,0);
            }
            case R -> {
                moveRight(0,0);
            }
            default -> throw new AssertionError();
        }
    }
    
    public void swichDirection(){
        switch (direction) {
            case L -> {
                this.direction = Direction.R;
            }
            case R -> {
                this.direction = Direction.L;
            }
            default -> throw new AssertionError();
        }
    }
    
    public boolean swichDirectionCondition(){
        return position.x < 10 || position.x > 1060-super.image.getIconWidth();
    }

    public boolean gameOverCondition(){
        return position.y > 640 - super.image.getIconHeight();
    }
    
    public void moveDown(int sleepMillis, int sleepNanos) {
        Point currentPosition = getPosition();
        setPosition(new Point(currentPosition.x, currentPosition.y + 15));
        try{
            Thread.sleep(sleepMillis,sleepNanos);
        }catch(InterruptedException e){}
    }
}
