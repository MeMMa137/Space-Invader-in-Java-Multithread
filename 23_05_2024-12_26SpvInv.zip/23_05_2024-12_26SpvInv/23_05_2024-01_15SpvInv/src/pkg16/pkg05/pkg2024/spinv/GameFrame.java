package pkg16.pkg05.pkg2024.spinv;

import javax.swing.JFrame;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class GameFrame extends JFrame{

    public GameFrame() {
        this.add(new GamePanel());
        this.setTitle("Space Invaders");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.pack();
        this.setResizable(false);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
    
}
